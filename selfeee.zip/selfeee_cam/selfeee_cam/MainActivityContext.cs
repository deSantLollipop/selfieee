﻿using Android.Content;

namespace selfeee_cam
{
    static class MainActivityContext
    {
        public static Context mContext;
        public static string userName;
        public static int id;
        public static LoginTable userData;
        public static bool Anonymous = false;
    }
}