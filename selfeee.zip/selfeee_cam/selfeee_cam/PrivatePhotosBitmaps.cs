﻿using Android.Graphics;
using System.Collections.Generic;

public static class PrivatePhotosBitmap
{
    public static Bitmap[] Bitmaps { get; set; }
    public static Dictionary<int, Bitmap> choosedBitmaps { get; set; }
    public static Bitmap UserProfileImage { get; set; }
}